import "./App.css";
import ImageClassifier from "./ImageClassifier";

function App() {
  return (
    <div>
      <ImageClassifier />
    </div>
  );
}

export default App;
